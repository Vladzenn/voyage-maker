# Art direction and continuity lock

The ordinary days worth going further for. Start with a city, find people within it, let their practice matter under pressure, then return to an ordinary invitation. This opening advertises a world and an emotional promise, rather than inventing a war, chosen one, villain plot or new quest.

## Canon and proposed staging

Ryūka Marufuji is the recurring canonical face. Her proud polish, small Arcane repertoire and awkward generosity provide the throughline. She is a twenty-year-old second-year student, not an Archon or invincible protagonist. GREEN eyes follow the current world JSON. The viewed local portrait draft has red eyes; all generation prompts explicitly resolve that conflict in favor of the JSON. Her expensive wand improves control and does not provide an external mana reserve.

Three supporting adults are original trailer designs. They are not inserted into game data and receive no purported canonical names or biographies:

| Production ID | Silhouette and locked design | Function in this cut |
|---|---|---|
| RED | Athletic olive-skinned woman, copper single braid, amber-brown eyes, red short mantle, charcoal tunic, dark trousers, boots, plain practice sword | A protective classmate whose movement grounds the action |
| CYAN | Dark-skinned man, short silver curls, brown eyes, thin brass spectacles, cyan sleeveless overcoat, cream shirt, navy trousers, brown tool satchel | Curiosity, measurement and an amused response to Ryūka |
| VIOLET | Tan-skinned man, hazel eyes, chestnut low knot, violet scarf, cream field jacket, dark trousers, herb satchel | Cooperation, practical preparation and calm |

Adoha Aonuma is depicted from her actual profile; her remote portrait was not viewed. She has blue eyes, very long blue hair, blue rose, black high-collared stage dress and a handheld magitech amplifier. Her performance does not injure or compel the crowd. Use an original vocalist: no celebrity voice imitation is requested.

Toki Toyama is grounded in the viewed historical local portrait and the current JSON. Gold curled horns, gold scales, cream-gold tail, violet bun, amber slit pupils, human face, teal robe and dark sash identify her. The reception shot asks for a securely wrapped working robe. She manages an onsen; its water does not cure aging or grant magical rejuvenation.

The four-person field sequence is illustrative promotional staging of a court-authorized, supervised expedition, not a recorded gameplay event. Do not infer a permanent party, new social relationship, scheduled cross-academy program or new mechanical privilege. Student status, skill and academy membership never substitute for travel authorization. An inconspicuous adult supervisor accompanies field shots. A later cut back home is an editorial ellipsis: all actual external return portals still lead to Evertree Base.

## Visual language

Polished 2D anime, crisp ink shapes, layered cel shading, beautiful expressive adult faces, richly painted environments and selective detail. No photographic skin, 3D plastic, mushy bloom or generic floating crystal effects. Widescreen theatrical staging overrides the portrait guides' vertical framing and standing-pose recipes because the user requested a 16:9 cinematic sequence. Their identity, rendering quality and anatomy guidance still applies. These are scene keyframes in `trailer/`, not replacement NPC portraits.

Use the generated shot 05 as the rendering and Ryūka identity anchor. Feed shots 03, 04 and 06 back as supporting-character references for group shots. Do not let a reference location contaminate another: Dragon Hoard's indoor display skeleton is not the sacred Drakenspire exterior skeleton. The local portrait's decorative heraldry is a visual reference, not proof of a new official emblem.

Academy palettes are red / cyan / yellow-gold / violet respectively. They identify institutions, not elemental restrictions, personality sorting or moral alignments. The choice of a small defensive working or a practical enchantment is trailer staging, not a new exclusive school spell.

## Location continuity

- Glowhaven: Evertree-centered, densely inhabited fantasy city and ordinary civic life. The Evertree makes local mana easier to sense and control; it is not established as the source of all mana. Ambient glints are subtle, not an apocalypse alarm.
- Phoenix Wing: marked practice lanes, padded posts and supervision. A legal drill is not an attack on the academy.
- Gryffin Tail: its formal magitech research joins actual engineering and enchantment. Brass mechanism, jig and tools; avoid holographic sci-fi control rooms or a perfected medical mana-transfer device.
- Dragon Hoard: yellow/gold exhibition displays, documented work and careful handling. A stone sample can be mundane. Presence and discovery do not establish ownership of a relic.
- Hydra Head: violet awnings, broad group tables, gardens, provisions and useful coordination. Not a generic purple wizard tower.
- Four Sages Bazaar: fountains, ordinary arcades, small shops and social warmth. It is the repeated social anchor in shots 07, 08, 15 and 16.
- Evertree Base Portal Room: enclosed vaulted receiving chamber, sole Glowhaven portal hub. Issued route key opens the matching ordinary arch. The destination immediately visible is Drakenspire's enclosed basalt receiving room, not open mountain sky.
- Drakenspire: inhabited lower southwestern mountain shelf; higher northeastern fortress shelf with ONE ancient dragon skeleton in a crescent around it. Physical sacred bones do not heat the city, power portals, awaken or become an enemy. Practical stone and slate, snow, cleared lanes, forge warmth.
- Stonewake Onsen: working reception, shoe racks, towels, ordinary cleaning and snow beyond. Bathhouse labor offers warmth without a sensual interlude or invented healing system.
- Asterveil: broad wilderness island surfaces and genuine sky gaps. Cloudbloom's small settlement satellite is not a giant sky capital. An attended carrier is a production interpretation of the documented crossing service, not free student flight. The four mapped regions are not four cities.
- Broken Halo Ruins: pale arcs, conifer-root setting, counterweights, a conservation shelter and connected undercroft. It once measured currents; it did not rule the archipelago. Use the existing survey approach for the retreat. Do not invent a treasure vault, sacrifice temple or world control machine.

## Threat and power discipline

The Hushbell Carapace must remain waist-high, with an oval charcoal shell, FOUR narrow legs, THREE dorsal hollow bell cups and TWO white eye bars. Its silence is local and temporary. It is a creature, not a demon, spider matron or endless enemy wave. The original encounter is one plausible instance, not an automatic spawn rule.

Ryūka's Slanted Ward is small, angled and vulnerable to stronger or sustained force. The action is one defensive beat and a retreat. No new spell, kill, loot, victory, relationship flag or quest completion is asserted. The Silken Descent and its surprise are deliberately left unspoiled; no Vhalessra reveal or alterations to that realm.

## Film grammar

Keep forward activity left-to-right until the homecoming. Alternate landscape, close observation, practical action, social ensemble and intimate face; avoid sixteen slow push-ins. Visual rhymes are edits rather than literal teleporting objects: dew → wand crystal → ward → research lens → specimen curve → work surface → sweet tin → fountain circle → portal arch → warm window → lantern → steam/cloud → dust → ward glint → tin → leaf.

The final leaf recalls the first without becoming a plot artifact. No invented shared crest. Graphic title only in editorial compositing, upper-left of shot 16. Safe title area: approximately x=8–55%, y=12–47%. Keep faces and identifying hair silhouettes readable; no text generation inside image/video prompts.

Do not remove grain, line variation and the drawn quality in video upscalers. Use restrained motion. Stabilize anatomy and layout rather than demanding simultaneous camera spins, sword choreography, lip sync, effects and a crowd simulation in the same clip.
