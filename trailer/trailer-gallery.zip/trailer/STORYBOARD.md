# The Schools of Magic, Arise! — anime opening storyboard

**90 seconds · 16 shots · 24 fps · 120 BPM · 45 bars in 4/4**

An opening about the city whose ordinary days are worth caring about: curiosity becomes practice, practice becomes company, and company becomes the courage to go further. Ryūka is the recurring canonical face, with three explicitly trailer-only adult classmates. The expedition montage is an illustrative trailer scenario, not a new canonical quest or a claim of completed gameplay.

These are generated reference keyframes and executable image-to-video briefs. Motion, a finished song and a Veo render are separate production steps. Read [art direction](ART_DIRECTION.md), [music/edit plan](edit/MUSIC_AND_EDIT.md), [source ledger](references/README.md), and [video recommendations](VIDEO_GENERATORS.md).

| Shot | Time | Length | Beat |

|---|---|---:|---|

| 01 | 00–06s | 6s | the city that teaches you to feel |

| 02 | 06–10s | 4s | a perfectly unnecessary polish |

| 03 | 10–16s | 6s | red means someone stands beside you |

| 04 | 16–20s | 4s | cyan a question in motion |

| 05 | 20–26s | 6s | gold the small discovery |

| 06 | 26–32s | 6s | violet making it work together |

| 07 | 32–36s | 4s | almost competent company |

| 08 | 36–42s | 6s | a city finds its voice |

| 09 | 42–48s | 6s | permission to go further |

| 10 | 48–56s | 8s | stone snow and an ancestors shelter |

| 11 | 56–62s | 6s | warmth is work too |

| 12 | 62–66s | 4s | the distance between islands |

| 13 | 66–72s | 6s | when the noise goes missing |

| 14 | 72–78s | 6s | a small ward is enough to begin |

| 15 | 78–84s | 6s | the invitation without a speech |

| 16 | 84–90s | 6s | arise |

## 01 · The City That Teaches You To Feel

**00–06s · 6 seconds · frames 0–143**

![Shot 01](images/01-the-city-that-teaches-you-to-feel.png)

**Narrative purpose:** Begin with wonder, then reveal the ordinary city worth protecting.

**Scene:** Sunrise establishing view of Glowhaven from near an Evertree leaf. One dew bead and a translucent green leaf dominate the extreme upper-left foreground; below, a densely inhabited fantasy city, homes, market roofs and a distant arena surround the enormous living Evertree. Its tree canopy is the hero landmark, not a world-sized floating island. Small red, cyan, gold and violet fabric accents punctuate inhabited streets, not four invented castles. Honey light, cool morning mist, no apocalyptic cracks, no world map, no colossal glowing energy beam.

**Music synchronization:** Bars 1–3. Exposed piano/chime motif, breath of flute, no percussion until the last beat.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Sunrise establishing view of Glowhaven from near an Evertree leaf. One dew bead and a translucent green leaf dominate the extreme upper-left foreground; below, a densely inhabited fantasy city, homes, market roofs and a distant arena surround the enormous living Evertree. Its tree canopy is the hero landmark, not a world-sized floating island. Small red, cyan, gold and violet fabric accents punctuate inhabited streets, not four invented castles. Honey light, cool morning mist, no apocalyptic cracks, no world map, no colossal glowing energy beam.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: macro focus on the dew bead, the city optically reflected inside. 2–5s: slow crane down and rack focus through the leaf to reveal Glowhaven; parallax separates roofs and trunk. 5–6s: the dew rolls out of frame. Leaf veins tremble in a breeze; chimney smoke rises. Keep the tree and skyline rigid, no architecture morphing. Cut on the descending bead to the crystal at the base of Ryūka’s wand in shot 02.

### Canonical references

- `WorldAlpha - World.json` → `regions/Glowhaven`

- `WorldAlpha - World.json` → `worldLore/The Evertree`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 02 · A Perfectly Unnecessary Polish

**06–10s · 4 seconds · frames 144–239**

![Shot 02](images/02-a-perfectly-unnecessary-polish.png)

**Narrative purpose:** Give a proud student a tiny, human ritual before the grand adventure.

**Scene:** Intimate over-desk low close view in a plausible Dragon Hoard dormitory study nook, warm morning window, yellow-gold fabric accents. Ryūka leans into frame from right, polishing her already immaculate slim wand with a cloth; a tin of tart apple sweets and closed spell notebook sit at left. The green crystal is at the wand base beside her fingers. Her GREEN eye and one black hoop are sharp, expression unreasonably serious. No readable timetable or invented personal heraldry. Keep all objects practical and small.

**Music synchronization:** Bars 4–5. Bass and light rim clicks enter; cloth snap lands on beat 4.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes. Intimate over-desk low close view in a plausible Dragon Hoard dormitory study nook, warm morning window, yellow-gold fabric accents. Ryūka leans into frame from right, polishing her already immaculate slim wand with a cloth; a tin of tart apple sweets and closed spell notebook sit at left. The green crystal is at the wand base beside her fingers. Her GREEN eye and one black hoop are sharp, expression unreasonably serious. No readable timetable or invented personal heraldry. Keep all objects practical and small.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1.5s: short slider move along the wand toward its green base crystal. 1.5–3s: Ryūka gives it one final cloth stroke and raises an eyebrow at her reflection. 3–4s: she snaps the cloth down, sleeve sweeping left-to-right across the lens. Animate only the right wrist, cloth, fringe and a small blink; retain wand geometry. Hard cut under the sleeve wipe to the red training mantle, same movement direction.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Dragon Hoard Academy/areas/Dragon Hoard Academy - Dormitory Wing`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 03 · Red Means Someone Stands Beside You

**10–16s · 6 seconds · frames 240–383**

![Shot 03](images/03-red-means-someone-stands-beside-you.png)

**Narrative purpose:** Make Phoenix Wing about responsible protection, not a generic fire house.

**Scene:** Low diagonal composition at Phoenix Wing Training Yard. Copper-braided adult student on left third, turned three-quarter, raising a compact amber ward with her free hand while her plain practice sword points safely down; one padded training post and clearly marked practice lanes occupy right. Red pennants, practical training architecture, an unobtrusive adult supervisor at a distance. A padded mechanical training arm meets the ward at chest height. Fierce concentration, planted feet, morning sun. No lethal fight, no burning school, no named Archon, no enormous blast.

**Music synchronization:** Bars 6–8. First full groove; snare at ward contact. A tiny breath follows the impact.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC. Low diagonal composition at Phoenix Wing Training Yard. Copper-braided adult student on left third, turned three-quarter, raising a compact amber ward with her free hand while her plain practice sword points safely down; one padded training post and clearly marked practice lanes occupy right. Red pennants, practical training architecture, an unobtrusive adult supervisor at a distance. A padded mechanical training arm meets the ward at chest height. Fierce concentration, planted feet, morning sun. No lethal fight, no burning school, no named Archon, no enormous blast.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: low lateral track along marked lanes toward her boots. 2–4s: she shifts one foot and lifts a short-lived ward; a single supervised padded practice arm presses against it and stops. 4–5s: coat hem and braid whip after her movement. 5–6s: hold on the ward edge as its round glint fills the right third. Use one clean defensive action, no extra sword swings. Match-cut the glint to a brass research lens in shot 04.

### Canonical references

- `WorldAlpha - World.json` → `locations/Phoenix Wing Academy`

- `WorldAlpha - World.json` → `locations/Phoenix Wing Academy/areas/Phoenix Wing Academy - Training Yard`

- `WorldAlpha - World.json` → `worldLore/Phoenix Wing Academy`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 04 · Cyan A Question In Motion

**16–20s · 4 seconds · frames 384–479**

![Shot 04](images/04-cyan-a-question-in-motion.png)

**Narrative purpose:** Show actual mechanical-magical research and curiosity.

**Scene:** Gryffin Tail Research Rooms, a richly furnished but practical bench, cyan banners and tall daylight windows. Silver-curled dark-skinned student in brass spectacles at right peers with delighted intensity at ONE palm-sized brass ring mechanism mounted securely in a wooden jig. A faint cyan enchanted indicator traces one measured arc as his fingers turn a physical screw. Books, calipers, hand-drawn non-legible notes. Foreground circular magnifier at left gives a strong graphic shape. This is modest supervised magitech research, not a futuristic hologram control room or a perfected mana-transfer machine.

**Music synchronization:** Bars 9–10. Woodwind answers piano; mechanism click joins the hi-hat pattern.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon. Gryffin Tail Research Rooms, a richly furnished but practical bench, cyan banners and tall daylight windows. Silver-curled dark-skinned student in brass spectacles at right peers with delighted intensity at ONE palm-sized brass ring mechanism mounted securely in a wooden jig. A faint cyan enchanted indicator traces one measured arc as his fingers turn a physical screw. Books, calipers, hand-drawn non-legible notes. Foreground circular magnifier at left gives a strong graphic shape. This is modest supervised magitech research, not a futuristic hologram control room or a perfected mana-transfer machine.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1s: rack focus from foreground magnifier to his eye behind spectacles. 1–3s: camera inches clockwise around the bench while he turns one screw; the mounted ring makes a quarter turn and its indicator steadies. 3–4s: his delighted smile is interrupted by a tiny mechanical click. Let a cyan curve exit screen right and match it to the green-white curve in shot 05. Avoid steam explosions and floating device parts.

### Canonical references

- `WorldAlpha - World.json` → `locations/Gryffin Tail Academy/areas/Gryffin Tail Academy - Research Rooms`

- `WorldAlpha - World.json` → `worldLore/Gryffin Tail Academy`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 05 · Gold The Small Discovery

**20–26s · 6 seconds · frames 480–623**

![Shot 05](images/05-gold-the-small-discovery.png)

**Narrative purpose:** Let precision and genuine interest show through Ryūka’s performance of superiority.

**Scene:** Dragon Hoard Exhibition Hall in late morning: Ryūka dominates the right third, guiding ONE small weathered ordinary stone specimen a few inches over a padded study tray with her slim wand. A single precise green-white Arcane curve outlines its short visible path; her left hand pauses near her chin. Rich gold dragon pennants, tall gallery windows and glass study cases in the left two thirds; practical documentation notebook diagonal in extreme foreground. Preserve green eyes, black hoops, platinum hair and exact outfit. Proud but absorbed, no world-altering relic, no ownership claim, no cosmic power.

**Music synchronization:** Bars 11–13. Strings add upward momentum; stone landing is a soft woodblock, not an explosion.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes. Dragon Hoard Exhibition Hall in late morning: Ryūka dominates the right third, guiding ONE small weathered ordinary stone specimen a few inches over a padded study tray with her slim wand. A single precise green-white Arcane curve outlines its short visible path; her left hand pauses near her chin. Rich gold dragon pennants, tall gallery windows and glass study cases in the left two thirds; practical documentation notebook diagonal in extreme foreground. Preserve green eyes, black hoops, platinum hair and exact outfit. Proud but absorbed, no world-altering relic, no ownership claim, no cosmic power.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: gentle push past the foreground notebook toward wand and stone. 2–4s: a tiny wrist adjustment rotates the stone a quarter-turn and lowers it safely onto the padded tray. 4–5s: her self-satisfied glance softens for half a second. 5–6s: a page lifts into foreground. Animate only the small object, wrist, hair tips and page. Cut on page white to the cream work surface in shot 06. The attached keyframe is the visual anchor for all later Ryūka shots.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Dragon Hoard Academy/areas/Dragon Hoard Academy - Exhibition Hall`

- `WorldAlpha - World.json` → `worldLore/Dragon Hoard Academy`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 06 · Violet Making It Work Together

**26–32s · 6 seconds · frames 624–767**

![Shot 06](images/06-violet-making-it-work-together.png)

**Narrative purpose:** Show practical cooperation, patience and useful magic.

**Scene:** A broad shared project table beneath Hydra Head violet awnings beside the Garden Walk. Chestnut-haired adult student at left holds a ceramic planter steady while two secondary adult classmates consult a simple unlabeled supply sketch and wrap a practical repaired support frame. One modest enchanted band glows softly around a cracked planter seam; a small herb plant remains ordinary and rooted. The hero looks up warmly at a classmate instead of posing toward camera. Garden branches, open seminars beyond, violet fabric, sunlit cream plaster and living greens, no botanical superweapon or giant bloom.

**Music synchronization:** Bars 14–16. Harmony warms; brushes and a playful bass pickup soften the academic montage.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. A broad shared project table beneath Hydra Head violet awnings beside the Garden Walk. Chestnut-haired adult student at left holds a ceramic planter steady while two secondary adult classmates consult a simple unlabeled supply sketch and wrap a practical repaired support frame. One modest enchanted band glows softly around a cracked planter seam; a small herb plant remains ordinary and rooted. The hero looks up warmly at a classmate instead of posing toward camera. Garden branches, open seminars beyond, violet fabric, sunlit cream plaster and living greens, no botanical superweapon or giant bloom.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: tabletop slider from a supply sketch to their joined work. 2–4s: he steadies the planter while a classmate tightens one support; a modest enchantment settles. 4–6s: he exhales and offers a pleased half-smile; a breeze lifts the violet awning and ripples sun shadows over the table. Cut on a round ceramic rim to a round sweets tin at the fountain. Keep hands assigned to one task each.

### Canonical references

- `WorldAlpha - World.json` → `locations/Hydra Head Academy`

- `WorldAlpha - World.json` → `locations/Hydra Head Academy/areas/Hydra Head Academy - Garden Walk`

- `WorldAlpha - World.json` → `worldLore/Hydra Head Academy`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 07 · Almost Competent Company

**32–36s · 4 seconds · frames 768–863**

![Shot 07](images/07-almost-competent-company.png)

**Narrative purpose:** Earn affection through awkward ordinary company before raising the stakes.

**Scene:** Four Sages Bazaar fountain ledge in afternoon, all four adult students in a loose asymmetrical group, fountain spray and ordinary market arcades behind. Ryūka at center-right extends her small open tin of tart apple sweets without looking directly at her companions, cheeks faintly pink and chin lifted. Red-braided woman reaches for exactly one sweet; cyan man suppresses a laugh, violet man smiles over a paper-wrapped ordinary snack. Each keeps their established costume and skin tone. Four people only in foreground, hands clearly separate, no romance claim, no academy joining ceremony.

**Music synchronization:** Bars 17–18. Half-bar drum dropout for the exchange; upbeat pickup launches the vocal entrance.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Four Sages Bazaar fountain ledge in afternoon, all four adult students in a loose asymmetrical group, fountain spray and ordinary market arcades behind. Ryūka at center-right extends her small open tin of tart apple sweets without looking directly at her companions, cheeks faintly pink and chin lifted. Red-braided woman reaches for exactly one sweet; cyan man suppresses a laugh, violet man smiles over a paper-wrapped ordinary snack. Each keeps their established costume and skin tone. Four people only in foreground, hands clearly separate, no romance claim, no academy joining ceremony.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1s: small handheld-style settle, not camera shake. 1–2.5s: Ryūka slides the tin toward the red student while looking away; one hand takes one sweet. 2.5–4s: cyan student lets out one amused breath; Ryūka turns a fraction too sharply, hair following. Fountain water continues behind them. Cut from the surprised inhalation to the bard’s breath in shot 08. Keep this underplayed and funny, not chibi.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Four Sages Bazaar`

- `WorldAlpha - World.json` → `worldLore/Festivals and Everyday Sociability`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 08 · A City Finds Its Voice

**36–42s · 6 seconds · frames 864–1007**

![Shot 08](images/08-a-city-finds-its-voice.png)

**Narrative purpose:** Turn the social world into the emotional voice of the opening.

**Scene:** Adoha Aonuma performing at Four Sages Fountain in late afternoon. Low close-medium three-quarter angle, bard on left, deep-blue hair flying across the lower-right diagonal, intense blue eyes, blue rose beside temple, black high-collared dress with white collar and subtle rose embroidery. Her black handheld magitech amplifier has a silver grille; a small accompaniment resonator stands near her feet. Fountain spray catches low golden sun behind her, crowd only small secondary silhouettes. Fierce expressive singing, beautiful human intensity, no electric concert stage, no attack magic, no compelled audience, no weapon.

**Music synchronization:** Bars 19–21. Original vocal refrain begins over double-time-feeling drums. Performance is an editorial musical bridge, not mind-control magic.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Adoha Aonuma, canonical adult human bard age 24, pale skin, intense blue eyes, very long deep-blue hair with cobalt highlights and uneven bangs, one vivid blue rose beside her temple. Black high-collared stage dress with white collar, dark ribbon, fitted sleeves, subtle blue rose embroidery. Black HANDHELD magitech voice amplifier with silver grille, small accompaniment resonator nearby, no weapon. Adoha Aonuma performing at Four Sages Fountain in late afternoon. Low close-medium three-quarter angle, bard on left, deep-blue hair flying across the lower-right diagonal, intense blue eyes, blue rose beside temple, black high-collared dress with white collar and subtle rose embroidery. Her black handheld magitech amplifier has a silver grille; a small accompaniment resonator stands near her feet. Fountain spray catches low golden sun behind her, crowd only small secondary silhouettes. Fierce expressive singing, beautiful human intensity, no electric concert stage, no attack magic, no compelled audience, no weapon.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: slow 20-degree orbit from her shoulder toward her face as she draws breath. 2–5s: she sings one rising sustained phrase into the handheld amplifier, one controlled hand gesture; hair and sleeve flutter, fountain spray drifts. 5–6s: she lowers her chin on the last accented syllable as the camera tilts toward a circular fountain highlight. Match that circle to the portal arch in shot 09. Preserve mouth anatomy; use an open-vowel performance if exact lip sync is unavailable. Do not generate a new song per clip.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Adoha Aonuma`

- `WorldAlpha - World.json` → `locations/Four Sages Bazaar`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 09 · Permission To Go Further

**42–48s · 6 seconds · frames 1008–1151**

![Shot 09](images/09-permission-to-go-further.png)

**Narrative purpose:** Make departure deliberate and shared, through the actual sole city hub.

**Scene:** Wide vaulted stone Evertree Base Portal Room, enclosed beneath rootward structures. One stone-framed arch opens onto the enclosed Drakenspire basalt receiving hall, NOT outdoors; a second inactive ordinary arch is secondary. The four adult students seen mostly from behind move toward the active passage left-to-right, their red, cyan, gold and violet costume silhouettes distinct. A secondary neutral-cloaked adult expedition supervisor stands beside a transit attendant and a small desk, reviewing issued physical route key and papers without readable writing. Warm Glowhaven stone against cool blue mineral light through the arch, dust in shafts, no school portal, no surprise monster or spider omen.

**Music synchronization:** Bars 22–24. Pre-chorus rising bass and bowed cymbal, final half-beat vacuum before the landscape drop.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Wide vaulted stone Evertree Base Portal Room, enclosed beneath rootward structures. One stone-framed arch opens onto the enclosed Drakenspire basalt receiving hall, NOT outdoors; a second inactive ordinary arch is secondary. The four adult students seen mostly from behind move toward the active passage left-to-right, their red, cyan, gold and violet costume silhouettes distinct. A secondary neutral-cloaked adult expedition supervisor stands beside a transit attendant and a small desk, reviewing issued physical route key and papers without readable writing. Warm Glowhaven stone against cool blue mineral light through the arch, dust in shafts, no school portal, no surprise monster or spider omen.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: low dolly behind boots approaching the threshold. 2–4s: attendant lowers the reviewed papers and supervisor gestures toward the authorized route; the party takes two steps. 4–6s: lens follows through the arch into an enclosed basalt receiving room with iron supports and brass channels. Do not morph the room into a mountain landscape. Cut on the dark basalt doorframe to an exterior Drakenspire reveal; allow an editorial time ellipsis.

### Canonical references

- `WorldAlpha - World.json` → `locations/Evertree Base/areas/Evertree Base - Portal Room`

- `WorldAlpha - World.json` → `worldLore/Authorized Student Expeditions`

- `WorldAlpha - World.json` → `worldLore/Portal Keys and Passage`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 10 · Stone Snow And An Ancestors Shelter

**48–56s · 8 seconds · frames 1152–1343**

![Shot 10](images/10-stone-snow-and-an-ancestors-shelter.png)

**Narrative purpose:** First full chorus payoff: a nation with history, scale and inhabited warmth.

**Scene:** Breathtaking oblique exterior panorama of snowy Drakenspire. Dense practical slate-roofed stone city on a lower southwestern shelf; distinctly higher shelf at upper right holds pale-gray Crescent Crown Fortress with square towers. ONE enormous ancient dragon skeleton curves around that higher fortress rock in a crescent, coherent single skull, spine and ribs, weathered physical bone, no glow or resurrection. Cleared steep lanes, warm windows, forge smoke and tiny dragonkin passersby in lower streets. Foreground dark slate roof and hanging wool-red awning, blue-white mountain distance. No Evertree, no floating city, no giant arena, no live dragon attacking.

**Music synchronization:** Bars 25–28. Chorus opens: broad strings, guitar octaves and full drums; give the reveal two bars before adding melody ornaments.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Breathtaking oblique exterior panorama of snowy Drakenspire. Dense practical slate-roofed stone city on a lower southwestern shelf; distinctly higher shelf at upper right holds pale-gray Crescent Crown Fortress with square towers. ONE enormous ancient dragon skeleton curves around that higher fortress rock in a crescent, coherent single skull, spine and ribs, weathered physical bone, no glow or resurrection. Cleared steep lanes, warm windows, forge smoke and tiny dragonkin passersby in lower streets. Foreground dark slate roof and hanging wool-red awning, blue-white mountain distance. No Evertree, no floating city, no giant arena, no live dragon attacking.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–3s: camera cranes above a lower-city roof, slowly revealing the higher fortress. 3–6s: the full single skeletal crescent resolves, with separate parallax on roofs, fortress and mountains. 6–8s: hold the awe; snow drifts diagonally while forge smoke rises independently. Bones and buildings stay physically fixed, absolutely no awakening. End by passing a warm amber window which becomes the lantern at the onsen in shot 11.

### Canonical references

- `WorldAlpha - World.json` → `realms/Drakenspire Mountains`

- `WorldAlpha - World.json` → `locations/Crescent Crown Fortress`

- `WorldAlpha - World.json` → `locations/The Ancestor's Crescent`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 11 · Warmth Is Work Too

**56–62s · 6 seconds · frames 1344–1487**

![Shot 11](images/11-warmth-is-work-too.png)

**Narrative purpose:** A warm comic breath inside the spectacle; show dragonkin as ordinary people.

**Scene:** At Stonewake Onsen reception and shoe racks, Toki Toyama offers a neatly folded towel across a low wooden reception counter to an unseen tired guest. Match the viewed local reference: violet bun, amber eyes, gold curled horns, human face, gold cheek scales, teal wrap robe, dark sash, cream-gold tail visible around the lower-right edge. Securely wrapped work clothing, warm professional smile. Shoe shelves, bathing-token tray, paper lanterns and an open view to snowy stone eaves; safe modest water-cleaning curl near an empty basin. No bathing scene, no combat, no rejuvenation pool, no erotic pose, no new powers.

**Music synchronization:** Bars 29–31. Chorus stays buoyant but strips the lead guitar; woodwind and a light rim accent carry her tiny joke.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Toki Toyama, canonical mature adult dragonkin woman: human face, violet hair in a high loose bun, amber slit-pupilled eyes, polished curled gold horns, gold scales at cheeks and forearms, thick cream-gold tail. Teal bathhouse robe securely wrapped for reception work, dark sash, practical sandals. Carries clean folded towels and a small bathing-token tray. Warm, capable manager, never a warrior. At Stonewake Onsen reception and shoe racks, Toki Toyama offers a neatly folded towel across a low wooden reception counter to an unseen tired guest. Match the viewed local reference: violet bun, amber eyes, gold curled horns, human face, gold cheek scales, teal wrap robe, dark sash, cream-gold tail visible around the lower-right edge. Securely wrapped work clothing, warm professional smile. Shoe shelves, bathing-token tray, paper lanterns and an open view to snowy stone eaves; safe modest water-cleaning curl near an empty basin. No bathing scene, no combat, no rejuvenation pool, no erotic pose, no new powers.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: small push from lantern to Toki’s attentive face. 2–4s: she offers one folded towel and raises an amused eyebrow as if reminding a guest to wash first. 4–6s: a thin ordinary wash-water stream settles into a basin; her tail makes one restrained sway. Warm steam remains background. Match a rising curl of steam to a cloud over Asterveil in shot 12; this is an editorial jump between separate expedition moments, not a new direct portal route.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Toki Toyama`

- `WorldAlpha - World.json` → `locations/Stonewake Onsen/areas/Stonewake Onsen - Reception and Shoe Racks`

- Viewed local artwork: [reference](references/toki-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 12 · The Distance Between Islands

**62–66s · 4 seconds · frames 1488–1583**

![Shot 12](images/12-the-distance-between-islands.png)

**Narrative purpose:** A second realm expands the visual vocabulary without inventing flight powers.

**Scene:** Asterveil Cloudbloom Reaches: side-on wide of the four adult students behind the waist-high rail of a modest attended carrier platform, with a secondary professional crossing crew member. Foreground flowering branches, one broad green woodland island, visible genuine sky gap, distant broad floating terraces and hanging roots. Strong lateral perspective, immense sky, limited small settlement detail toward the sheltered satellite. Characters small but costumes readable, no one flying or jumping gaps; no four floating cities, no winged generic fae crowd, no ocean ship, no bridge invented across the entire realm.

**Music synchronization:** Bars 32–33. Vocal reaches upward, cymbal wash, then sharply remove high frequencies on the next cut.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Asterveil Cloudbloom Reaches: side-on wide of the four adult students behind the waist-high rail of a modest attended carrier platform, with a secondary professional crossing crew member. Foreground flowering branches, one broad green woodland island, visible genuine sky gap, distant broad floating terraces and hanging roots. Strong lateral perspective, immense sky, limited small settlement detail toward the sheltered satellite. Characters small but costumes readable, no one flying or jumping gaps; no four floating cities, no winged generic fae crowd, no ocean ship, no bridge invented across the entire realm.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1s: foreground cloud slides away. 1–3s: track parallel with the attended carrier, the party behind its safe rail, branches passing close to lens while distant terraces barely shift. 3–4s: Ryūka’s hair lifts and the red student rests a hand on the rail. Maintain rigid carrier geometry and fixed feet. End on a floating seed crossing frame; cut to dust drifting silently beneath the ruins in shot 13. The carrier is a production design for the documented attended crossing, not a new transport system.

### Canonical references

- `WorldAlpha - World.json` → `realms/Asterveil Sky Archipelago`

- `WorldAlpha - World.json` → `regions/Cloudbloom Reaches`

- `WorldAlpha - World.json` → `locations/Cloudbloom Landing`

- `WorldAlpha - World.json` → `worldLore/Asterveil Crossings and Field Safety`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 13 · When The Noise Goes Missing

**66–72s · 6 seconds · frames 1584–1727**

![Shot 13](images/13-when-the-noise-goes-missing.png)

**Narrative purpose:** Introduce a specific, bounded threat through silence instead of generic evil.

**Scene:** Broken Halo Ruins Undercroft, low cold stone passage with old counterweights, pale blue reflected light and dust. Extreme low viewpoint from behind ONE Hushbell Carapace: waist-high oval charcoal shell on FOUR narrow legs, THREE hollow bell cups on flexible dorsal stems turned toward the floor; low head partly visible with TWO white eye bars. It approaches cautiously, not a colossal boss. In the upper-right background Ryūka, small in frame, notices dust vibrating against a flagstone and turns her green eye toward the creature. Preserve recognizable gold-trim robe, platinum hair and wand. No spider queen, no skull demon, no permanent anti-magic field, no loot beam.

**Music synchronization:** Bars 34–36. Sound-design dip for local creature silence; piano heartbeat and dry bass remain editorially audible. No claim all magic is disabled.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes. Broken Halo Ruins Undercroft, low cold stone passage with old counterweights, pale blue reflected light and dust. Extreme low viewpoint from behind ONE Hushbell Carapace: waist-high oval charcoal shell on FOUR narrow legs, THREE hollow bell cups on flexible dorsal stems turned toward the floor; low head partly visible with TWO white eye bars. It approaches cautiously, not a colossal boss. In the upper-right background Ryūka, small in frame, notices dust vibrating against a flagstone and turns her green eye toward the creature. Preserve recognizable gold-trim robe, platinum hair and wand. No spider queen, no skull demon, no permanent anti-magic field, no loot beam.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: almost-locked low camera, extremely slow creep; creature lifts one narrow leg and places it silently. 2–4s: dorsal cups dip toward the floor; dust trembles in a shallow crack. 4–6s: rack focus to Ryūka’s eye as she stops, plants a foot and begins to raise her wand. Keep exactly four legs and three cups, no multiplying anatomy. Cut on her inhale to the ward action in shot 14, same left-to-right travel axis.

### Canonical references

- `WorldAlpha - World.json` → `locations/Broken Halo Ruins/areas/Broken Halo Ruins - Undercroft`

- `WorldAlpha - World.json` → `npcTypes/Hushbell Carapace`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 14 · A Small Ward Is Enough To Begin

**72–78s · 6 seconds · frames 1728–1871**

![Shot 14](images/14-a-small-ward-is-enough-to-begin.png)

**Narrative purpose:** Pay off learning and companionship through a limited defensive retreat, not sudden godhood.

**Scene:** Inside the SAME low stone undercroft with counterweights, dynamic low side angle. Ryūka right-of-center in three-quarter profile, two clearly green eyes where visible, platinum hair and gold-trim robe, right hand holding her slim wand to form ONE SMALL angled green-white Arcane Slanted Ward at torso height between party and an offscreen threat. Left arm balances behind her, no second wand. Red-braided adult student at left foreground turns to protect the retreat lane with plain sword in a compact guard; cyan and violet classmates already withdraw toward the existing survey-approach exit in the background, with a secondary expedition supervisor directing them. Hard diagonal flagstones and flying dust, narrow light slashing across determined faces. Ward occupies under one third of image, no giant dome, no killing blow, no new treasure, no new escape tunnel.

**Music synchronization:** Bars 37–39. Final chorus returns with impact on the snare; brief harmonic lift as they choose one another over a trophy.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Inside the SAME low stone undercroft with counterweights, dynamic low side angle. Ryūka right-of-center in three-quarter profile, two clearly green eyes where visible, platinum hair and gold-trim robe, right hand holding her slim wand to form ONE SMALL angled green-white Arcane Slanted Ward at torso height between party and an offscreen threat. Left arm balances behind her, no second wand. Red-braided adult student at left foreground turns to protect the retreat lane with plain sword in a compact guard; cyan and violet classmates already withdraw toward the existing survey-approach exit in the background, with a secondary expedition supervisor directing them. Hard diagonal flagstones and flying dust, narrow light slashing across determined faces. Ward occupies under one third of image, no giant dome, no killing blow, no new treasure, no new escape tunnel.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1s: Ryūka plants her rear foot. 1–3s: ONE wrist stroke raises a small angled ward; an implied modest impact skids along its face as a short light streak. 3–5s: red student covers the lane while Ryūka takes one controlled retreating step, cyan and violet move toward the existing exit. 5–6s: camera tracks with Ryūka’s determined face and catches one green-white glint. Hair and dust lag behind movement. No spin, no power-up costume, no full enemy defeat, no broken weapon. Match the glint to the sweet tin opening in shot 15.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Broken Halo Ruins/areas/Broken Halo Ruins - Undercroft`

- `WorldAlpha - World.json` → `npcTypes/Hushbell Carapace`

- `WorldAlpha - World.json` → `worldLore/Authorized Student Expeditions`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 15 · The Invitation Without A Speech

**78–84s · 6 seconds · frames 1872–2015**

![Shot 15](images/15-the-invitation-without-a-speech.png)

**Narrative purpose:** Resolve the emotional arc in a tiny change, leaving adventure open.

**Scene:** Back at Four Sages Bazaar fountain after an editorial return home, evening blue-hour and warm shop lamps. Tight two-person composition: Ryūka on right with unchanged platinum hair, GREEN eyes, gold-trim uniform and black hoops, holds her small open apple-sweets tin between herself and the copper-braided red student at left. This time Ryūka looks straight at her companion, faint vulnerable almost-smile under a still-proud lifted chin; red student meets it without mockery. Their fingers do not touch or merge. Foreground fountain rim and quiet rippling water, distant stalls soft. No kiss, no declaration of permanent friendship or romance, no scar or redesign.

**Music synchronization:** Bars 40–42. Vocal falls to an intimate phrase over piano and bass, then strings build into the title cadence.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC. Back at Four Sages Bazaar fountain after an editorial return home, evening blue-hour and warm shop lamps. Tight two-person composition: Ryūka on right with unchanged platinum hair, GREEN eyes, gold-trim uniform and black hoops, holds her small open apple-sweets tin between herself and the copper-braided red student at left. This time Ryūka looks straight at her companion, faint vulnerable almost-smile under a still-proud lifted chin; red student meets it without mockery. Their fingers do not touch or merge. Foreground fountain rim and quiet rippling water, distant stalls soft. No kiss, no declaration of permanent friendship or romance, no scar or redesign.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: restrained push toward the tin. 2–4s: Ryūka offers it, then lets her gaze meet her companion instead of turning away as in shot 07. 4–6s: the companion smiles, Ryūka exhales and glances down once, hair settling. Water ripples and evening lamps flicker subtly. Cut on their shared upward look toward the Evertree in shot 16. Let acting, not a magical spectacle, finish this beat.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Four Sages Bazaar`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.

## 16 · Arise

**84–90s · 6 seconds · frames 2016–2159**

![Shot 16](images/16-arise.png)

**Narrative purpose:** Return to the first image changed by companionship; leave the world inviting.

**Scene:** Final blue-hour fantasy-anime hero composition from a public Glowhaven street near Four Sages Bazaar, seen just behind and beside the four adult students in the LOWER RIGHT third, not on restricted Evertree grounds. Ryūka glances back over her shoulder with the smallest proud smile, GREEN eye visible, platinum hair, gold-trim robe; red braid, cyan silver curls and violet scarf create three distinct companion silhouettes beside her. Above the inhabited roofline the enormous Evertree lifts luminous leaves into the indigo evening; shop lights and windows make the city feel lived in. Leave the upper-left and center-left sky beautifully simple for editorial title lettering. One ordinary leaf drifts toward lens, a visual echo of shot 01, not a new magical artifact. No rainbow mega-beam or world-saving coronation.

**Music synchronization:** Bars 43–45. Full original refrain and a rising final chord; chime signature on the title settle, ringing to the exact 90s end.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Final blue-hour fantasy-anime hero composition from a public Glowhaven street near Four Sages Bazaar, seen just behind and beside the four adult students in the LOWER RIGHT third, not on restricted Evertree grounds. Ryūka glances back over her shoulder with the smallest proud smile, GREEN eye visible, platinum hair, gold-trim robe; red braid, cyan silver curls and violet scarf create three distinct companion silhouettes beside her. Above the inhabited roofline the enormous Evertree lifts luminous leaves into the indigo evening; shop lights and windows make the city feel lived in. Leave the upper-left and center-left sky beautifully simple for editorial title lettering. One ordinary leaf drifts toward lens, a visual echo of shot 01, not a new magical artifact. No rainbow mega-beam or world-saving coronation.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: slow pullback and slight upward crane reveal the quartet beneath the Evertree skyline. 2–4s: Ryūka makes a single over-shoulder glance, companions continue watching the city, one leaf drifts diagonally toward camera. 4–6s: hold a living tableau, only hair tips, leaves and distant smoke moving. Composite the title in the editor from 86.5s; settle it by 88s and hold through 90s. No model-generated letters. Final leaf wipes naturally to black AFTER the 90-second picture endpoint.

### Canonical references

- `WorldAlpha - World.json` → `regions/Glowhaven`

- `WorldAlpha - World.json` → `worldLore/The Evertree`

- `WorldAlpha - World.json` → `locations/Four Sages Bazaar`

- Viewed local artwork: [reference](references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
