# Which video generators to use for this opening

**My first choice for this particular project is Veo through Flow or a Gemini interface that exposes image-to-video and suitable reference controls.** The storyboard already has carefully staged keyframes; begin with their motion, not a text-only attempt at all ninety seconds. For difficult character action, compare a short Kling test before spending on a full run. Finish the sequence in a conventional editor.

This is a task-specific recommendation, not a current benchmark or a verified list of the newest model releases. No live web-research tool or authenticated video generator is available in this session. Availability, supported clip lengths, input/reference controls, watermarks, regional access, prices and commercial terms must be checked in the actual product. No video model was run for this deliverable.

| Tool / family | Where I would use it here | What to inspect before paying |
|---|---|---|
| **Google Veo / Flow** | Primary candidate: the Evertree reveal, academy atmosphere, Adoha's performance plate, Drakenspire and onsen; test character-preserving shots against the supplied keyframes | Actual image-to-video mode, available reference-image or first/last-frame controls, supported aspect ratio/durations and whether it preserves drawn faces rather than turning them realistic. Flow and Gemini may expose different controls. |
| **Kling** | Comparative candidate for shot 03's defensive drill and shot 14's small ward/retreat; short action tests with strong starting images | Hand/weapon stability, weight transfer, line-art retention, eye color and robe continuity. Do not assume a spectacular motion result preserves the design. |
| **Runway** | Alternative for deliberate, restrained character/camera beats and a production pipeline with iterative shot control | Which current model and reference controls your plan exposes; test shots 07 and 15, where tiny facial acting matters more than spectacle. |
| **Luma Dream Machine** | Additional test for landscape parallax and controlled camera/scene movement | Building rigidity and stability of the single Drakenspire skeleton; avoid flashy environment morphing that changes geography. |
| **Adobe Firefly Video** | Consider when the existing editing workflow and commercial-production requirements favor Adobe integration | Verify current terms, provenance features and what is actually available for image-led generation in your account; do not infer blanket rights from a brand name. |

Useful official starting points: [Google Flow](https://labs.google/flow/about), [Gemini video](https://gemini.google/overview/video-generation/), [Google DeepMind Veo](https://deepmind.google/models/veo/), [Kling](https://klingai.com/), [Runway](https://runwayml.com/), [Luma](https://lumalabs.ai/dream-machine), [Adobe Firefly](https://www.adobe.com/products/firefly.html). Links are supplied for checking the current offering; their contents were not browsed in this session.

## A practical selection test

Generate the same three approved keyframes in two candidate products before choosing: shot 05 (Ryūka identity and wand), shot 10 (rigid architecture and one skeleton), shot 14 (small ward, hands and safe retreat). Compare at normal speed and frame by frame. Score identity, coherent motion, anatomy/prop stability, camera obedience and drawn rendering from 1–5. Choose the winner by usable footage per generation rather than a single impressive frame. Budget hero shots separately from inexpensive camera-only plates.

For this cut I would start **Veo/Flow for the full visual baseline, Kling as an action alternative, and DaVinci Resolve or Premiere for the 90-second edit**. Keep shots 07 and 15 understated; aggressive motion would erase their emotional point. An external face/lip-sync pass is only worth adding after the music and Adoha's performance are locked.

Gemini is useful as a shot-planning and review assistant, and may expose Veo generation depending on the interface. Calling a prompt “for Gemini/Veo” does not mean Gemini and Veo are separate interchangeable video engines. Use the controls your interface actually provides; a prompt cannot enable a feature absent from the product.
