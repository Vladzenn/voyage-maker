# 90-second music and edit plan

**Picture:** 90.000 seconds, 24 fps, 2,160 frames, 16:9 timeline at 1920×1080. Image generators may deliver a near-16:9 native raster; conform without stretching, using an imperceptible edge crop or padding in the video edit. Keep the native reference PNGs intact. **Music:** 120 BPM, 4/4, 45 bars. One beat is 0.5s, one bar is 2s. Every picture cut is on a bar boundary. Drums may feel double-time during the chorus; the underlying tempo remains 120.

## Arrangement map

| Time | Bars | Picture / musical function |
|---|---|---|
| 0–6 | 1–3 | Evertree and city; piano, airy flute, a distinctive three-note chime figure |
| 6–20 | 4–10 | Personal ritual, red drill, cyan research; bass and increasingly syncopated percussion |
| 20–32 | 11–16 | Gold study and violet collaboration; rising strings, warm harmonic color |
| 32–36 | 17–18 | Awkward sweets exchange; short drum dropout and a playful pickup |
| 36–42 | 19–21 | Adoha's visual vocal entrance; original strong but expressive lead vocal |
| 42–48 | 22–24 | Authorized departure; pre-chorus rise and a half-beat breath before the reveal |
| 48–56 | 25–28 | First expansive chorus: Drakenspire; guitar octaves, strings, powerful live-feeling drums |
| 56–62 | 29–31 | Toki and onsen warmth; woodwind answers vocal without halting momentum |
| 62–66 | 32–33 | Asterveil sky gap; ascending phrase and airborne cymbal wash |
| 66–72 | 34–36 | Hushbell silence; diegetic high frequencies drop out, sparse piano heartbeat |
| 72–78 | 37–39 | Small ward and group retreat; final chorus impact, relief rather than kill fanfare |
| 78–84 | 40–42 | Evening invitation; close vocal, piano and bass, strings begin rebuilding |
| 84–90 | 43–45 | Ensemble and Evertree; broad final cadence, title settles by 88s, final chime |

This incorporates the repository's everyday piano/bass/woodwind/chime identity and warm groove, while expanding into an opening's guitar/string spectacle. The score's modern instruments do not imply modern in-world technology. Do not duplicate or imitate a named singer's voice. Adoha's pictured performance can be cut to the original singer; it is not a claim of an existing canonical recording.

## Original music-production prompt

Create an original 90-second fantasy-anime opening, exactly 120 BPM in 4/4 with a 45-bar picture map. Warm piano/Rhodes, rounded bass, flute/clarinet and a recognizable three-note chime motif introduce a lived-in magical school city. Grow into energetic drums with double-time-feeling hats, bright guitar octaves and soaring strings. Expressive original English female lead, intimate and wry before becoming fierce and hopeful; no imitation of a real performer. Theme: learning imperfectly, inviting someone along, going further together and having ordinary days to return to. Vocal entrance at 36s, expansive chorus at 48s, human warmth at 56s, airborne lift at 62s, local silence/dry piano at 66s, final chorus at 72s, tender invitation at 78s, title cadence at 84–90s. End on a resonant chime. No lore lecture, villain prophecy or world-saving exposition.

This is a composition brief, not a generated audio file. If a music generator misses the time map, edit stems or have a composer arrange to the picture; do not silently move the locked cuts and call it synchronized. A scratch lyric theme could use the original refrain “A little further / leave a light for me,” but no lyric is locked until a real performance is chosen.

## Clip generation and conform

1. Lock and approve stills first. Upload each shot's actual PNG, plus a small number of relevant identity references if the chosen video product supports them. Ask Gemini to inspect the source image and prompt; Veo performs the video generation where available. Do not rely on a file path pasted into a web prompt to upload the image.
2. Generate one plate per shot. The timing inside each prompt is the intended editorial duration, not a guarantee of the generator's native output lengths. If your Veo surface offers only 4/6/8-second clips, choose the next available length; for another tool with 5/10-second increments, choose a longer clip with a hold at the end and trim. Verify the actual model/surface before committing credits.
3. Generate small motion ranges first: one defensive movement, one expression, one camera move. Use fast previs modes to test the camera and anatomy, then spend higher-quality generations on shots 05, 08, 10, 14 and 16.
4. Extract candidate frames and compare hair, eyes, outfit, hand assignment, prop geometry and backgrounds. Reject temporal morphing, a gem migrating to the wand tip, changing skin tone or extra monster limbs. Strength of a single frame does not establish temporal consistency.
5. For shot 14, prioritize a readable small ward and retreat over full-body weapon choreography. Split it into short generated action components in the editor if needed, keeping the total six-second shot as one coherent sequence. Do not expand the 90-second cut.
6. Keep all generated clip music muted. Build one continuous score and a separate effects bed. The Hushbell effect changes nearby diegetic sound; the editorial music can retain piano and bass. Use a separately controlled vocal/open-vowel plate for Adoha; exact lip sync is optional, not assumed.
7. Trim on the locked bar boundaries. Most transitions are straight or matched cuts. Portal, cloth and leaf occlusions can conceal a cut. Do not add default dissolves to every shot or ask a model to morph one landscape into another.
8. Composite the exact title **The Schools of Magic, Arise!** from 86.5s, settled by 88s. Keep it inside the left sky safe area. Match the art with restrained ivory lettering and a fine gold accent; no invented academy crest. Title treatment is a production proposal.
9. Export at 1920×1080, 24fps, 90.000s, Rec.709, with the final approved stereo music mix. Keep generation masters and lossless keyframes separately.

## Included animatic

`keyframe-animatic.mp4` is a silent cut of the sixteen still keyframes at their exact durations. It proves editorial pacing and image sequence only. It has no synthesized character animation, camera motion, recorded score or dialogue. `keyframes.ffconcat` is the source list for rebuilding the timing cut. The actual transition and motion instructions live in each shot brief.
