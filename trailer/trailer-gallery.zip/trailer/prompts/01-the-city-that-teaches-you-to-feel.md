## 01 · The City That Teaches You To Feel

**00–06s · 6 seconds · frames 0–143**

![Shot 01](../images/01-the-city-that-teaches-you-to-feel.png)

**Narrative purpose:** Begin with wonder, then reveal the ordinary city worth protecting.

**Scene:** Sunrise establishing view of Glowhaven from near an Evertree leaf. One dew bead and a translucent green leaf dominate the extreme upper-left foreground; below, a densely inhabited fantasy city, homes, market roofs and a distant arena surround the enormous living Evertree. Its tree canopy is the hero landmark, not a world-sized floating island. Small red, cyan, gold and violet fabric accents punctuate inhabited streets, not four invented castles. Honey light, cool morning mist, no apocalyptic cracks, no world map, no colossal glowing energy beam.

**Music synchronization:** Bars 1–3. Exposed piano/chime motif, breath of flute, no percussion until the last beat.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Sunrise establishing view of Glowhaven from near an Evertree leaf. One dew bead and a translucent green leaf dominate the extreme upper-left foreground; below, a densely inhabited fantasy city, homes, market roofs and a distant arena surround the enormous living Evertree. Its tree canopy is the hero landmark, not a world-sized floating island. Small red, cyan, gold and violet fabric accents punctuate inhabited streets, not four invented castles. Honey light, cool morning mist, no apocalyptic cracks, no world map, no colossal glowing energy beam.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: macro focus on the dew bead, the city optically reflected inside. 2–5s: slow crane down and rack focus through the leaf to reveal Glowhaven; parallax separates roofs and trunk. 5–6s: the dew rolls out of frame. Leaf veins tremble in a breeze; chimney smoke rises. Keep the tree and skyline rigid, no architecture morphing. Cut on the descending bead to the crystal at the base of Ryūka’s wand in shot 02.

### Canonical references

- `WorldAlpha - World.json` → `regions/Glowhaven`

- `WorldAlpha - World.json` → `worldLore/The Evertree`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
