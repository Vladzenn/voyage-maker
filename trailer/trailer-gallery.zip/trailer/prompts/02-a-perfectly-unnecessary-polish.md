## 02 · A Perfectly Unnecessary Polish

**06–10s · 4 seconds · frames 144–239**

![Shot 02](../images/02-a-perfectly-unnecessary-polish.png)

**Narrative purpose:** Give a proud student a tiny, human ritual before the grand adventure.

**Scene:** Intimate over-desk low close view in a plausible Dragon Hoard dormitory study nook, warm morning window, yellow-gold fabric accents. Ryūka leans into frame from right, polishing her already immaculate slim wand with a cloth; a tin of tart apple sweets and closed spell notebook sit at left. The green crystal is at the wand base beside her fingers. Her GREEN eye and one black hoop are sharp, expression unreasonably serious. No readable timetable or invented personal heraldry. Keep all objects practical and small.

**Music synchronization:** Bars 4–5. Bass and light rim clicks enter; cloth snap lands on beat 4.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes. Intimate over-desk low close view in a plausible Dragon Hoard dormitory study nook, warm morning window, yellow-gold fabric accents. Ryūka leans into frame from right, polishing her already immaculate slim wand with a cloth; a tin of tart apple sweets and closed spell notebook sit at left. The green crystal is at the wand base beside her fingers. Her GREEN eye and one black hoop are sharp, expression unreasonably serious. No readable timetable or invented personal heraldry. Keep all objects practical and small.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1.5s: short slider move along the wand toward its green base crystal. 1.5–3s: Ryūka gives it one final cloth stroke and raises an eyebrow at her reflection. 3–4s: she snaps the cloth down, sleeve sweeping left-to-right across the lens. Animate only the right wrist, cloth, fringe and a small blink; retain wand geometry. Hard cut under the sleeve wipe to the red training mantle, same movement direction.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Dragon Hoard Academy/areas/Dragon Hoard Academy - Dormitory Wing`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
