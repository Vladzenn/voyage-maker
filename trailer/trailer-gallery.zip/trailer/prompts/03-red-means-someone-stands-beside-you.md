## 03 · Red Means Someone Stands Beside You

**10–16s · 6 seconds · frames 240–383**

![Shot 03](../images/03-red-means-someone-stands-beside-you.png)

**Narrative purpose:** Make Phoenix Wing about responsible protection, not a generic fire house.

**Scene:** Low diagonal composition at Phoenix Wing Training Yard. Copper-braided adult student on left third, turned three-quarter, raising a compact amber ward with her free hand while her plain practice sword points safely down; one padded training post and clearly marked practice lanes occupy right. Red pennants, practical training architecture, an unobtrusive adult supervisor at a distance. A padded mechanical training arm meets the ward at chest height. Fierce concentration, planted feet, morning sun. No lethal fight, no burning school, no named Archon, no enormous blast.

**Music synchronization:** Bars 6–8. First full groove; snare at ward contact. A tiny breath follows the impact.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC. Low diagonal composition at Phoenix Wing Training Yard. Copper-braided adult student on left third, turned three-quarter, raising a compact amber ward with her free hand while her plain practice sword points safely down; one padded training post and clearly marked practice lanes occupy right. Red pennants, practical training architecture, an unobtrusive adult supervisor at a distance. A padded mechanical training arm meets the ward at chest height. Fierce concentration, planted feet, morning sun. No lethal fight, no burning school, no named Archon, no enormous blast.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: low lateral track along marked lanes toward her boots. 2–4s: she shifts one foot and lifts a short-lived ward; a single supervised padded practice arm presses against it and stops. 4–5s: coat hem and braid whip after her movement. 5–6s: hold on the ward edge as its round glint fills the right third. Use one clean defensive action, no extra sword swings. Match-cut the glint to a brass research lens in shot 04.

### Canonical references

- `WorldAlpha - World.json` → `locations/Phoenix Wing Academy`

- `WorldAlpha - World.json` → `locations/Phoenix Wing Academy/areas/Phoenix Wing Academy - Training Yard`

- `WorldAlpha - World.json` → `worldLore/Phoenix Wing Academy`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
