## 04 · Cyan A Question In Motion

**16–20s · 4 seconds · frames 384–479**

![Shot 04](../images/04-cyan-a-question-in-motion.png)

**Narrative purpose:** Show actual mechanical-magical research and curiosity.

**Scene:** Gryffin Tail Research Rooms, a richly furnished but practical bench, cyan banners and tall daylight windows. Silver-curled dark-skinned student in brass spectacles at right peers with delighted intensity at ONE palm-sized brass ring mechanism mounted securely in a wooden jig. A faint cyan enchanted indicator traces one measured arc as his fingers turn a physical screw. Books, calipers, hand-drawn non-legible notes. Foreground circular magnifier at left gives a strong graphic shape. This is modest supervised magitech research, not a futuristic hologram control room or a perfected mana-transfer machine.

**Music synchronization:** Bars 9–10. Woodwind answers piano; mechanism click joins the hi-hat pattern.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon. Gryffin Tail Research Rooms, a richly furnished but practical bench, cyan banners and tall daylight windows. Silver-curled dark-skinned student in brass spectacles at right peers with delighted intensity at ONE palm-sized brass ring mechanism mounted securely in a wooden jig. A faint cyan enchanted indicator traces one measured arc as his fingers turn a physical screw. Books, calipers, hand-drawn non-legible notes. Foreground circular magnifier at left gives a strong graphic shape. This is modest supervised magitech research, not a futuristic hologram control room or a perfected mana-transfer machine.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1s: rack focus from foreground magnifier to his eye behind spectacles. 1–3s: camera inches clockwise around the bench while he turns one screw; the mounted ring makes a quarter turn and its indicator steadies. 3–4s: his delighted smile is interrupted by a tiny mechanical click. Let a cyan curve exit screen right and match it to the green-white curve in shot 05. Avoid steam explosions and floating device parts.

### Canonical references

- `WorldAlpha - World.json` → `locations/Gryffin Tail Academy/areas/Gryffin Tail Academy - Research Rooms`

- `WorldAlpha - World.json` → `worldLore/Gryffin Tail Academy`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
