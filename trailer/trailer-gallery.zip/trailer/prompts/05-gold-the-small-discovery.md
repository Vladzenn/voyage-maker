## 05 · Gold The Small Discovery

**20–26s · 6 seconds · frames 480–623**

![Shot 05](../images/05-gold-the-small-discovery.png)

**Narrative purpose:** Let precision and genuine interest show through Ryūka’s performance of superiority.

**Scene:** Dragon Hoard Exhibition Hall in late morning: Ryūka dominates the right third, guiding ONE small weathered ordinary stone specimen a few inches over a padded study tray with her slim wand. A single precise green-white Arcane curve outlines its short visible path; her left hand pauses near her chin. Rich gold dragon pennants, tall gallery windows and glass study cases in the left two thirds; practical documentation notebook diagonal in extreme foreground. Preserve green eyes, black hoops, platinum hair and exact outfit. Proud but absorbed, no world-altering relic, no ownership claim, no cosmic power.

**Music synchronization:** Bars 11–13. Strings add upward momentum; stone landing is a soft woodblock, not an explosion.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes. Dragon Hoard Exhibition Hall in late morning: Ryūka dominates the right third, guiding ONE small weathered ordinary stone specimen a few inches over a padded study tray with her slim wand. A single precise green-white Arcane curve outlines its short visible path; her left hand pauses near her chin. Rich gold dragon pennants, tall gallery windows and glass study cases in the left two thirds; practical documentation notebook diagonal in extreme foreground. Preserve green eyes, black hoops, platinum hair and exact outfit. Proud but absorbed, no world-altering relic, no ownership claim, no cosmic power.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: gentle push past the foreground notebook toward wand and stone. 2–4s: a tiny wrist adjustment rotates the stone a quarter-turn and lowers it safely onto the padded tray. 4–5s: her self-satisfied glance softens for half a second. 5–6s: a page lifts into foreground. Animate only the small object, wrist, hair tips and page. Cut on page white to the cream work surface in shot 06. The attached keyframe is the visual anchor for all later Ryūka shots.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Dragon Hoard Academy/areas/Dragon Hoard Academy - Exhibition Hall`

- `WorldAlpha - World.json` → `worldLore/Dragon Hoard Academy`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
