## 06 · Violet Making It Work Together

**26–32s · 6 seconds · frames 624–767**

![Shot 06](../images/06-violet-making-it-work-together.png)

**Narrative purpose:** Show practical cooperation, patience and useful magic.

**Scene:** A broad shared project table beneath Hydra Head violet awnings beside the Garden Walk. Chestnut-haired adult student at left holds a ceramic planter steady while two secondary adult classmates consult a simple unlabeled supply sketch and wrap a practical repaired support frame. One modest enchanted band glows softly around a cracked planter seam; a small herb plant remains ordinary and rooted. The hero looks up warmly at a classmate instead of posing toward camera. Garden branches, open seminars beyond, violet fabric, sunlit cream plaster and living greens, no botanical superweapon or giant bloom.

**Music synchronization:** Bars 14–16. Harmony warms; brushes and a playful bass pickup soften the academic montage.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. A broad shared project table beneath Hydra Head violet awnings beside the Garden Walk. Chestnut-haired adult student at left holds a ceramic planter steady while two secondary adult classmates consult a simple unlabeled supply sketch and wrap a practical repaired support frame. One modest enchanted band glows softly around a cracked planter seam; a small herb plant remains ordinary and rooted. The hero looks up warmly at a classmate instead of posing toward camera. Garden branches, open seminars beyond, violet fabric, sunlit cream plaster and living greens, no botanical superweapon or giant bloom.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: tabletop slider from a supply sketch to their joined work. 2–4s: he steadies the planter while a classmate tightens one support; a modest enchantment settles. 4–6s: he exhales and offers a pleased half-smile; a breeze lifts the violet awning and ripples sun shadows over the table. Cut on a round ceramic rim to a round sweets tin at the fountain. Keep hands assigned to one task each.

### Canonical references

- `WorldAlpha - World.json` → `locations/Hydra Head Academy`

- `WorldAlpha - World.json` → `locations/Hydra Head Academy/areas/Hydra Head Academy - Garden Walk`

- `WorldAlpha - World.json` → `worldLore/Hydra Head Academy`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
