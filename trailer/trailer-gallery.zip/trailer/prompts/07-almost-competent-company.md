## 07 · Almost Competent Company

**32–36s · 4 seconds · frames 768–863**

![Shot 07](../images/07-almost-competent-company.png)

**Narrative purpose:** Earn affection through awkward ordinary company before raising the stakes.

**Scene:** Four Sages Bazaar fountain ledge in afternoon, all four adult students in a loose asymmetrical group, fountain spray and ordinary market arcades behind. Ryūka at center-right extends her small open tin of tart apple sweets without looking directly at her companions, cheeks faintly pink and chin lifted. Red-braided woman reaches for exactly one sweet; cyan man suppresses a laugh, violet man smiles over a paper-wrapped ordinary snack. Each keeps their established costume and skin tone. Four people only in foreground, hands clearly separate, no romance claim, no academy joining ceremony.

**Music synchronization:** Bars 17–18. Half-bar drum dropout for the exchange; upbeat pickup launches the vocal entrance.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Four Sages Bazaar fountain ledge in afternoon, all four adult students in a loose asymmetrical group, fountain spray and ordinary market arcades behind. Ryūka at center-right extends her small open tin of tart apple sweets without looking directly at her companions, cheeks faintly pink and chin lifted. Red-braided woman reaches for exactly one sweet; cyan man suppresses a laugh, violet man smiles over a paper-wrapped ordinary snack. Each keeps their established costume and skin tone. Four people only in foreground, hands clearly separate, no romance claim, no academy joining ceremony.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1s: small handheld-style settle, not camera shake. 1–2.5s: Ryūka slides the tin toward the red student while looking away; one hand takes one sweet. 2.5–4s: cyan student lets out one amused breath; Ryūka turns a fraction too sharply, hair following. Fountain water continues behind them. Cut from the surprised inhalation to the bard’s breath in shot 08. Keep this underplayed and funny, not chibi.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Four Sages Bazaar`

- `WorldAlpha - World.json` → `worldLore/Festivals and Everyday Sociability`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
