## 08 · A City Finds Its Voice

**36–42s · 6 seconds · frames 864–1007**

![Shot 08](../images/08-a-city-finds-its-voice.png)

**Narrative purpose:** Turn the social world into the emotional voice of the opening.

**Scene:** Adoha Aonuma performing at Four Sages Fountain in late afternoon. Low close-medium three-quarter angle, bard on left, deep-blue hair flying across the lower-right diagonal, intense blue eyes, blue rose beside temple, black high-collared dress with white collar and subtle rose embroidery. Her black handheld magitech amplifier has a silver grille; a small accompaniment resonator stands near her feet. Fountain spray catches low golden sun behind her, crowd only small secondary silhouettes. Fierce expressive singing, beautiful human intensity, no electric concert stage, no attack magic, no compelled audience, no weapon.

**Music synchronization:** Bars 19–21. Original vocal refrain begins over double-time-feeling drums. Performance is an editorial musical bridge, not mind-control magic.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Adoha Aonuma, canonical adult human bard age 24, pale skin, intense blue eyes, very long deep-blue hair with cobalt highlights and uneven bangs, one vivid blue rose beside her temple. Black high-collared stage dress with white collar, dark ribbon, fitted sleeves, subtle blue rose embroidery. Black HANDHELD magitech voice amplifier with silver grille, small accompaniment resonator nearby, no weapon. Adoha Aonuma performing at Four Sages Fountain in late afternoon. Low close-medium three-quarter angle, bard on left, deep-blue hair flying across the lower-right diagonal, intense blue eyes, blue rose beside temple, black high-collared dress with white collar and subtle rose embroidery. Her black handheld magitech amplifier has a silver grille; a small accompaniment resonator stands near her feet. Fountain spray catches low golden sun behind her, crowd only small secondary silhouettes. Fierce expressive singing, beautiful human intensity, no electric concert stage, no attack magic, no compelled audience, no weapon.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: slow 20-degree orbit from her shoulder toward her face as she draws breath. 2–5s: she sings one rising sustained phrase into the handheld amplifier, one controlled hand gesture; hair and sleeve flutter, fountain spray drifts. 5–6s: she lowers her chin on the last accented syllable as the camera tilts toward a circular fountain highlight. Match that circle to the portal arch in shot 09. Preserve mouth anatomy; use an open-vowel performance if exact lip sync is unavailable. Do not generate a new song per clip.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Adoha Aonuma`

- `WorldAlpha - World.json` → `locations/Four Sages Bazaar`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
