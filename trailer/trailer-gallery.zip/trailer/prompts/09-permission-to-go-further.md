## 09 · Permission To Go Further

**42–48s · 6 seconds · frames 1008–1151**

![Shot 09](../images/09-permission-to-go-further.png)

**Narrative purpose:** Make departure deliberate and shared, through the actual sole city hub.

**Scene:** Wide vaulted stone Evertree Base Portal Room, enclosed beneath rootward structures. One stone-framed arch opens onto the enclosed Drakenspire basalt receiving hall, NOT outdoors; a second inactive ordinary arch is secondary. The four adult students seen mostly from behind move toward the active passage left-to-right, their red, cyan, gold and violet costume silhouettes distinct. A secondary neutral-cloaked adult expedition supervisor stands beside a transit attendant and a small desk, reviewing issued physical route key and papers without readable writing. Warm Glowhaven stone against cool blue mineral light through the arch, dust in shafts, no school portal, no surprise monster or spider omen.

**Music synchronization:** Bars 22–24. Pre-chorus rising bass and bowed cymbal, final half-beat vacuum before the landscape drop.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Wide vaulted stone Evertree Base Portal Room, enclosed beneath rootward structures. One stone-framed arch opens onto the enclosed Drakenspire basalt receiving hall, NOT outdoors; a second inactive ordinary arch is secondary. The four adult students seen mostly from behind move toward the active passage left-to-right, their red, cyan, gold and violet costume silhouettes distinct. A secondary neutral-cloaked adult expedition supervisor stands beside a transit attendant and a small desk, reviewing issued physical route key and papers without readable writing. Warm Glowhaven stone against cool blue mineral light through the arch, dust in shafts, no school portal, no surprise monster or spider omen.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: low dolly behind boots approaching the threshold. 2–4s: attendant lowers the reviewed papers and supervisor gestures toward the authorized route; the party takes two steps. 4–6s: lens follows through the arch into an enclosed basalt receiving room with iron supports and brass channels. Do not morph the room into a mountain landscape. Cut on the dark basalt doorframe to an exterior Drakenspire reveal; allow an editorial time ellipsis.

### Canonical references

- `WorldAlpha - World.json` → `locations/Evertree Base/areas/Evertree Base - Portal Room`

- `WorldAlpha - World.json` → `worldLore/Authorized Student Expeditions`

- `WorldAlpha - World.json` → `worldLore/Portal Keys and Passage`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
