## 10 · Stone Snow And An Ancestors Shelter

**48–56s · 8 seconds · frames 1152–1343**

![Shot 10](../images/10-stone-snow-and-an-ancestors-shelter.png)

**Narrative purpose:** First full chorus payoff: a nation with history, scale and inhabited warmth.

**Scene:** Breathtaking oblique exterior panorama of snowy Drakenspire. Dense practical slate-roofed stone city on a lower southwestern shelf; distinctly higher shelf at upper right holds pale-gray Crescent Crown Fortress with square towers. ONE enormous ancient dragon skeleton curves around that higher fortress rock in a crescent, coherent single skull, spine and ribs, weathered physical bone, no glow or resurrection. Cleared steep lanes, warm windows, forge smoke and tiny dragonkin passersby in lower streets. Foreground dark slate roof and hanging wool-red awning, blue-white mountain distance. No Evertree, no floating city, no giant arena, no live dragon attacking.

**Music synchronization:** Bars 25–28. Chorus opens: broad strings, guitar octaves and full drums; give the reveal two bars before adding melody ornaments.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Breathtaking oblique exterior panorama of snowy Drakenspire. Dense practical slate-roofed stone city on a lower southwestern shelf; distinctly higher shelf at upper right holds pale-gray Crescent Crown Fortress with square towers. ONE enormous ancient dragon skeleton curves around that higher fortress rock in a crescent, coherent single skull, spine and ribs, weathered physical bone, no glow or resurrection. Cleared steep lanes, warm windows, forge smoke and tiny dragonkin passersby in lower streets. Foreground dark slate roof and hanging wool-red awning, blue-white mountain distance. No Evertree, no floating city, no giant arena, no live dragon attacking.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–3s: camera cranes above a lower-city roof, slowly revealing the higher fortress. 3–6s: the full single skeletal crescent resolves, with separate parallax on roofs, fortress and mountains. 6–8s: hold the awe; snow drifts diagonally while forge smoke rises independently. Bones and buildings stay physically fixed, absolutely no awakening. End by passing a warm amber window which becomes the lantern at the onsen in shot 11.

### Canonical references

- `WorldAlpha - World.json` → `realms/Drakenspire Mountains`

- `WorldAlpha - World.json` → `locations/Crescent Crown Fortress`

- `WorldAlpha - World.json` → `locations/The Ancestor's Crescent`

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
