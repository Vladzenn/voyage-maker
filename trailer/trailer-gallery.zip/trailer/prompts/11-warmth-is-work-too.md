## 11 · Warmth Is Work Too

**56–62s · 6 seconds · frames 1344–1487**

![Shot 11](../images/11-warmth-is-work-too.png)

**Narrative purpose:** A warm comic breath inside the spectacle; show dragonkin as ordinary people.

**Scene:** At Stonewake Onsen reception and shoe racks, Toki Toyama offers a neatly folded towel across a low wooden reception counter to an unseen tired guest. Match the viewed local reference: violet bun, amber eyes, gold curled horns, human face, gold cheek scales, teal wrap robe, dark sash, cream-gold tail visible around the lower-right edge. Securely wrapped work clothing, warm professional smile. Shoe shelves, bathing-token tray, paper lanterns and an open view to snowy stone eaves; safe modest water-cleaning curl near an empty basin. No bathing scene, no combat, no rejuvenation pool, no erotic pose, no new powers.

**Music synchronization:** Bars 29–31. Chorus stays buoyant but strips the lead guitar; woodwind and a light rim accent carry her tiny joke.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Toki Toyama, canonical mature adult dragonkin woman: human face, violet hair in a high loose bun, amber slit-pupilled eyes, polished curled gold horns, gold scales at cheeks and forearms, thick cream-gold tail. Teal bathhouse robe securely wrapped for reception work, dark sash, practical sandals. Carries clean folded towels and a small bathing-token tray. Warm, capable manager, never a warrior. At Stonewake Onsen reception and shoe racks, Toki Toyama offers a neatly folded towel across a low wooden reception counter to an unseen tired guest. Match the viewed local reference: violet bun, amber eyes, gold curled horns, human face, gold cheek scales, teal wrap robe, dark sash, cream-gold tail visible around the lower-right edge. Securely wrapped work clothing, warm professional smile. Shoe shelves, bathing-token tray, paper lanterns and an open view to snowy stone eaves; safe modest water-cleaning curl near an empty basin. No bathing scene, no combat, no rejuvenation pool, no erotic pose, no new powers.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: small push from lantern to Toki’s attentive face. 2–4s: she offers one folded towel and raises an amused eyebrow as if reminding a guest to wash first. 4–6s: a thin ordinary wash-water stream settles into a basin; her tail makes one restrained sway. Warm steam remains background. Match a rising curl of steam to a cloud over Asterveil in shot 12; this is an editorial jump between separate expedition moments, not a new direct portal route.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Toki Toyama`

- `WorldAlpha - World.json` → `locations/Stonewake Onsen/areas/Stonewake Onsen - Reception and Shoe Racks`

- Viewed local artwork: [reference](../references/toki-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
