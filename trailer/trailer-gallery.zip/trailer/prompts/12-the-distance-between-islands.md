## 12 · The Distance Between Islands

**62–66s · 4 seconds · frames 1488–1583**

![Shot 12](../images/12-the-distance-between-islands.png)

**Narrative purpose:** A second realm expands the visual vocabulary without inventing flight powers.

**Scene:** Asterveil Cloudbloom Reaches: side-on wide of the four adult students behind the waist-high rail of a modest attended carrier platform, with a secondary professional crossing crew member. Foreground flowering branches, one broad green woodland island, visible genuine sky gap, distant broad floating terraces and hanging roots. Strong lateral perspective, immense sky, limited small settlement detail toward the sheltered satellite. Characters small but costumes readable, no one flying or jumping gaps; no four floating cities, no winged generic fae crowd, no ocean ship, no bridge invented across the entire realm.

**Music synchronization:** Bars 32–33. Vocal reaches upward, cymbal wash, then sharply remove high frequencies on the next cut.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Asterveil Cloudbloom Reaches: side-on wide of the four adult students behind the waist-high rail of a modest attended carrier platform, with a secondary professional crossing crew member. Foreground flowering branches, one broad green woodland island, visible genuine sky gap, distant broad floating terraces and hanging roots. Strong lateral perspective, immense sky, limited small settlement detail toward the sheltered satellite. Characters small but costumes readable, no one flying or jumping gaps; no four floating cities, no winged generic fae crowd, no ocean ship, no bridge invented across the entire realm.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1s: foreground cloud slides away. 1–3s: track parallel with the attended carrier, the party behind its safe rail, branches passing close to lens while distant terraces barely shift. 3–4s: Ryūka’s hair lifts and the red student rests a hand on the rail. Maintain rigid carrier geometry and fixed feet. End on a floating seed crossing frame; cut to dust drifting silently beneath the ruins in shot 13. The carrier is a production design for the documented attended crossing, not a new transport system.

### Canonical references

- `WorldAlpha - World.json` → `realms/Asterveil Sky Archipelago`

- `WorldAlpha - World.json` → `regions/Cloudbloom Reaches`

- `WorldAlpha - World.json` → `locations/Cloudbloom Landing`

- `WorldAlpha - World.json` → `worldLore/Asterveil Crossings and Field Safety`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
