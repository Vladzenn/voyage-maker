## 13 · When The Noise Goes Missing

**66–72s · 6 seconds · frames 1584–1727**

![Shot 13](../images/13-when-the-noise-goes-missing.png)

**Narrative purpose:** Introduce a specific, bounded threat through silence instead of generic evil.

**Scene:** Broken Halo Ruins Undercroft, low cold stone passage with old counterweights, pale blue reflected light and dust. Extreme low viewpoint from behind ONE Hushbell Carapace: waist-high oval charcoal shell on FOUR narrow legs, THREE hollow bell cups on flexible dorsal stems turned toward the floor; low head partly visible with TWO white eye bars. It approaches cautiously, not a colossal boss. In the upper-right background Ryūka, small in frame, notices dust vibrating against a flagstone and turns her green eye toward the creature. Preserve recognizable gold-trim robe, platinum hair and wand. No spider queen, no skull demon, no permanent anti-magic field, no loot beam.

**Music synchronization:** Bars 34–36. Sound-design dip for local creature silence; piano heartbeat and dry bass remain editorially audible. No claim all magic is disabled.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes. Broken Halo Ruins Undercroft, low cold stone passage with old counterweights, pale blue reflected light and dust. Extreme low viewpoint from behind ONE Hushbell Carapace: waist-high oval charcoal shell on FOUR narrow legs, THREE hollow bell cups on flexible dorsal stems turned toward the floor; low head partly visible with TWO white eye bars. It approaches cautiously, not a colossal boss. In the upper-right background Ryūka, small in frame, notices dust vibrating against a flagstone and turns her green eye toward the creature. Preserve recognizable gold-trim robe, platinum hair and wand. No spider queen, no skull demon, no permanent anti-magic field, no loot beam.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: almost-locked low camera, extremely slow creep; creature lifts one narrow leg and places it silently. 2–4s: dorsal cups dip toward the floor; dust trembles in a shallow crack. 4–6s: rack focus to Ryūka’s eye as she stops, plants a foot and begins to raise her wand. Keep exactly four legs and three cups, no multiplying anatomy. Cut on her inhale to the ward action in shot 14, same left-to-right travel axis.

### Canonical references

- `WorldAlpha - World.json` → `locations/Broken Halo Ruins/areas/Broken Halo Ruins - Undercroft`

- `WorldAlpha - World.json` → `npcTypes/Hushbell Carapace`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
