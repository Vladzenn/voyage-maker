## 14 · A Small Ward Is Enough To Begin

**72–78s · 6 seconds · frames 1728–1871**

![Shot 14](../images/14-a-small-ward-is-enough-to-begin.png)

**Narrative purpose:** Pay off learning and companionship through a limited defensive retreat, not sudden godhood.

**Scene:** Inside the SAME low stone undercroft with counterweights, dynamic low side angle. Ryūka right-of-center in three-quarter profile, two clearly green eyes where visible, platinum hair and gold-trim robe, right hand holding her slim wand to form ONE SMALL angled green-white Arcane Slanted Ward at torso height between party and an offscreen threat. Left arm balances behind her, no second wand. Red-braided adult student at left foreground turns to protect the retreat lane with plain sword in a compact guard; cyan and violet classmates already withdraw toward the existing survey-approach exit in the background, with a secondary expedition supervisor directing them. Hard diagonal flagstones and flying dust, narrow light slashing across determined faces. Ward occupies under one third of image, no giant dome, no killing blow, no new treasure, no new escape tunnel.

**Music synchronization:** Bars 37–39. Final chorus returns with impact on the snare; brief harmonic lift as they choose one another over a trophy.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Inside the SAME low stone undercroft with counterweights, dynamic low side angle. Ryūka right-of-center in three-quarter profile, two clearly green eyes where visible, platinum hair and gold-trim robe, right hand holding her slim wand to form ONE SMALL angled green-white Arcane Slanted Ward at torso height between party and an offscreen threat. Left arm balances behind her, no second wand. Red-braided adult student at left foreground turns to protect the retreat lane with plain sword in a compact guard; cyan and violet classmates already withdraw toward the existing survey-approach exit in the background, with a secondary expedition supervisor directing them. Hard diagonal flagstones and flying dust, narrow light slashing across determined faces. Ward occupies under one third of image, no giant dome, no killing blow, no new treasure, no new escape tunnel.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–1s: Ryūka plants her rear foot. 1–3s: ONE wrist stroke raises a small angled ward; an implied modest impact skids along its face as a short light streak. 3–5s: red student covers the lane while Ryūka takes one controlled retreating step, cyan and violet move toward the existing exit. 5–6s: camera tracks with Ryūka’s determined face and catches one green-white glint. Hair and dust lag behind movement. No spin, no power-up costume, no full enemy defeat, no broken weapon. Match the glint to the sweet tin opening in shot 15.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Broken Halo Ruins/areas/Broken Halo Ruins - Undercroft`

- `WorldAlpha - World.json` → `npcTypes/Hushbell Carapace`

- `WorldAlpha - World.json` → `worldLore/Authorized Student Expeditions`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
