## 15 · The Invitation Without A Speech

**78–84s · 6 seconds · frames 1872–2015**

![Shot 15](../images/15-the-invitation-without-a-speech.png)

**Narrative purpose:** Resolve the emotional arc in a tiny change, leaving adventure open.

**Scene:** Back at Four Sages Bazaar fountain after an editorial return home, evening blue-hour and warm shop lamps. Tight two-person composition: Ryūka on right with unchanged platinum hair, GREEN eyes, gold-trim uniform and black hoops, holds her small open apple-sweets tin between herself and the copper-braided red student at left. This time Ryūka looks straight at her companion, faint vulnerable almost-smile under a still-proud lifted chin; red student meets it without mockery. Their fingers do not touch or merge. Foreground fountain rim and quiet rippling water, distant stalls soft. No kiss, no declaration of permanent friendship or romance, no scar or redesign.

**Music synchronization:** Bars 40–42. Vocal falls to an intimate phrase over piano and bass, then strings build into the title cadence.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC. Back at Four Sages Bazaar fountain after an editorial return home, evening blue-hour and warm shop lamps. Tight two-person composition: Ryūka on right with unchanged platinum hair, GREEN eyes, gold-trim uniform and black hoops, holds her small open apple-sweets tin between herself and the copper-braided red student at left. This time Ryūka looks straight at her companion, faint vulnerable almost-smile under a still-proud lifted chin; red student meets it without mockery. Their fingers do not touch or merge. Foreground fountain rim and quiet rippling water, distant stalls soft. No kiss, no declaration of permanent friendship or romance, no scar or redesign.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: restrained push toward the tin. 2–4s: Ryūka offers it, then lets her gaze meet her companion instead of turning away as in shot 07. 4–6s: the companion smiles, Ryūka exhales and glances down once, hair settling. Water ripples and evening lamps flicker subtly. Cut on their shared upward look toward the Evertree in shot 16. Let acting, not a magical spectacle, finish this beat.

### Canonical references

- `WorldAlpha - World.json` → `npcs/Ryūka Marufuji`

- `WorldAlpha - World.json` → `locations/Four Sages Bazaar`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
