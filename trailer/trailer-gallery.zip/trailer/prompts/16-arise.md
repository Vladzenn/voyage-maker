## 16 · Arise

**84–90s · 6 seconds · frames 2016–2159**

![Shot 16](../images/16-arise.png)

**Narrative purpose:** Return to the first image changed by companionship; leave the world inviting.

**Scene:** Final blue-hour fantasy-anime hero composition from a public Glowhaven street near Four Sages Bazaar, seen just behind and beside the four adult students in the LOWER RIGHT third, not on restricted Evertree grounds. Ryūka glances back over her shoulder with the smallest proud smile, GREEN eye visible, platinum hair, gold-trim robe; red braid, cyan silver curls and violet scarf create three distinct companion silhouettes beside her. Above the inhabited roofline the enormous Evertree lifts luminous leaves into the indigo evening; shop lights and windows make the city feel lived in. Leave the upper-left and center-left sky beautifully simple for editorial title lettering. One ordinary leaf drifts toward lens, a visual echo of shot 01, not a new magical artifact. No rainbow mega-beam or world-saving coronation.

**Music synchronization:** Bars 43–45. Full original refrain and a rising final chord; chime signature on the title settle, ringing to the exact 90s end.

### Image-generation prompt

One beautiful full-frame 16:9 landscape cinematic fantasy anime opening keyframe. Match the supplied Ryuka keyframe for rendering quality: unmistakable polished 2D anime, deliberate clean ink contours, expressive drawn eyes, fine layered cel shading on characters, richly painted fantasy backgrounds, atmospheric perspective, selective intricate detail, crisp silhouettes and carefully directed light. Dynamic purposeful composition with foreground, midground and background; one readable emotional or action beat. No photorealism, semi-realism, CGI, plastic skin, modern city, unreadable effect clutter, extra limbs, duplicated people, character sheets, split panels, borders, captions, letters, logos, watermark or UI. No generated title text; title will be composited in the edit. Ryūka Marufuji, canonical adult human woman age 20: slender, fair skin, very long straight platinum-blond hair parted off-center, vivid GREEN eyes, smoky eyeliner, large black hoop earrings. White blouse, yellow striped necktie, charcoal V-neck vest, black robe with yellow-gold trim and lining, pleated skirt, opaque black stockings. Slim dark wooden wand with silver grip collar and tiny pale-green crystal at its BASE. Proud sidelong expression, imperious chin, embarrassment expressed as indignation. The older supplied portrait has red eyes: override ONLY that conflict with current JSON green eyes.  Trailer-only adult Phoenix Wing student, woman about 23, athletic, warm olive skin, amber-brown eyes, copper-red hair in a single thick braid, short red academy mantle over charcoal practical tunic, leather belt, dark trousers, boots, plain training sword. Direct protective energy, no resemblance to a named canon NPC.  Trailer-only adult Gryffin Tail student, man about 24, dark brown skin, short tightly curled silver-gray hair, brown eyes, round thin brass spectacles, cyan sleeveless academic overcoat over cream rolled-sleeve shirt, navy trousers, small brown tool satchel. Curious expressive face; no staff or oversized weapon.  Trailer-only adult Hydra Head student, man about 25, tan skin, hazel eyes, wavy chestnut hair tied in a small low knot, violet scarf and violet-trimmed cream field jacket, dark trousers, herb satchel. Thoughtful relaxed warmth. Final blue-hour fantasy-anime hero composition from a public Glowhaven street near Four Sages Bazaar, seen just behind and beside the four adult students in the LOWER RIGHT third, not on restricted Evertree grounds. Ryūka glances back over her shoulder with the smallest proud smile, GREEN eye visible, platinum hair, gold-trim robe; red braid, cyan silver curls and violet scarf create three distinct companion silhouettes beside her. Above the inhabited roofline the enormous Evertree lifts luminous leaves into the indigo evening; shop lights and windows make the city feel lived in. Leave the upper-left and center-left sky beautifully simple for editorial title lettering. One ordinary leaf drifts toward lens, a visual echo of shot 01, not a new magical artifact. No rainbow mega-beam or world-saving coronation.

### Gemini / Veo image-to-video prompt

Use this shot’s supplied keyframe as the identity, layout, material and light anchor. Deliver a silent 16:9 24fps animation plate, preserving crisp 2D anime rendering. No dialogue, music, captions, watermark, new characters or additional camera cuts inside the plate. Maintain face, eye color, costume, grip, anatomy and architecture frame to frame. 0–2s: slow pullback and slight upward crane reveal the quartet beneath the Evertree skyline. 2–4s: Ryūka makes a single over-shoulder glance, companions continue watching the city, one leaf drifts diagonally toward camera. 4–6s: hold a living tableau, only hair tips, leaves and distant smoke moving. Composite the title in the editor from 86.5s; settle it by 88s and hold through 90s. No model-generated letters. Final leaf wipes naturally to black AFTER the 90-second picture endpoint.

### Canonical references

- `WorldAlpha - World.json` → `regions/Glowhaven`

- `WorldAlpha - World.json` → `worldLore/The Evertree`

- `WorldAlpha - World.json` → `locations/Four Sages Bazaar`

- Viewed local artwork: [reference](../references/ryuka-local-draft.png). Historical draft; current JSON wins conflicts.

- Existing location artwork URLs and full scene records are retained in `references/canonical-excerpts.json`; remote CDN images were not viewable during initial research.

**Generation status:** generated.
