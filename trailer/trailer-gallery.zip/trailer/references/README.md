# Canonical source and artwork ledger

Primary source is `world-draft/WorldAlpha - World.json` at the checkout recorded in `canonical-excerpts.json`. `shots.json` records its SHA-256 and exact object paths for every shot. `build_storyboard.py` resolves every cited path against the world JSON; it does not write that JSON.

Study also included `AGENTS.override.md`, `docs/CURRENT_STATE.md`, `docs/DECISIONS.md`, `research/Portrait Creation Format.md`, `research/Location and Area Image Creation Guide.md`, `world-draft/Drakenspire - Map Art Brief.md` and `world-draft/Soundtrack Bible - Beta.md`. The soundtrack bible is a working production plan, not proof of an existing recorded opening song.

| Reference | Actual viewing status | Use / limit |
|---|---|---|
| `ryuka-local-draft.png`, copied from `research/portrait drafts/Ryūka Marufuji - Dragon Hoard red eyes.png` | Visually inspected | Strong face, hair, costume and rendering anchor. Historical red-eye version conflicts with current GREEN eyes; JSON wins. It is not represented as the current hosted portrait. |
| `toki-local-draft.png`, copied from `research/portrait drafts/Toki Toyama - before modest regeneration 2026-10-29.png` | Visually inspected | Identity and onsen visual language. Historical draft, not proof of current hosted image. Shot 11 requests a securely wrapped work robe. |
| Ryūka current hosted portrait, `npcs/Ryūka Marufuji/portraitUrl` | URL recorded, not viewed | Do not claim pixel-level match to this image. |
| Toki current hosted portrait, `npcs/Toki Toyama/portraitUrl` | URL recorded, not viewed | Current JSON appearance remains authoritative. |
| Adoha current hosted portrait, `npcs/Adoha Aonuma/portraitUrl` | URL recorded, not viewed | Shot 08 is profile-grounded, not a direct portrait match. |
| Academy establishing shots and area shots | URL fields retained in `canonical-excerpts.json`, not viewed | Scene descriptions establish facts; architecture/rendering beyond them is production design. |
| Glowhaven, Drakenspire and Cloudbloom maps | URLs in canonical world region records, not viewed | Use authored geographic descriptions; do not claim traced map geography. |
| Generated shot 05 | Generated and visually inspected | Rendering and recurring Ryūka identity anchor for this production. |
| Generated shots 03, 04 and 06 | See `review/VISUAL_REVIEW.md` | Original adult supporting-student designs, used as image references for later group scenes. |

The managed proxy initially returned a 403 policy denial for `latitude-standard-pull-zone-1.b-cdn.net`. An additive allowance for that exact hostname was saved in the environment configuration draft; saving does not apply it to the running instance. No TLS verification was disabled and no network restriction was bypassed. No credential is required merely to use this offline storyboard.

All CDN URLs are retained as existing artwork references, not asserted accessible assets. Large indexed desktop originals were not present in this cloud checkout. Original references are copied for a self-contained trailer folder and their source files remain unchanged.

Trailer-only staging includes the three original students, their casual encounters with Ryūka, an illustrative supervised expedition and a bounded defensive retreat. These are proposals for the opening, not changes to canonical biographies, game state, world geography or future expansion plans.
